import React, { useState, useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import Page1 from './pages/Page1';
import Page2 from './pages/Page2';

export default function App() {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageData, setPageData] = useState({});

  const handleNext = (data) => {
    console.log('handleNext called with data:', data);
    setPageData(data);
    setCurrentPage(2);
  };

  const handleBack = () => {
    setCurrentPage(1);
  };

  return (
    <View style={styles.container}>
      {currentPage === 1 ? (
        <Page1 onNext={handleNext} />
      ) : (
        <Page2 data={pageData} onBack={handleBack} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
