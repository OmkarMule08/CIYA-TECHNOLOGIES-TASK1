import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Dimensions, Platform, KeyboardAvoidingView, ScrollView, Keyboard } from 'react-native';
import QRScanner from '../components/QRScanner'; // Make sure your QRScanner supports custom styles
import DateTimePicker from '@react-native-community/datetimepicker';

// Get screen dimensions
const { width, height } = Dimensions.get('window');

export default function Page1({ onNext }) {
  const [qrValues, setQrValues] = useState({ scanner1: '', scanner2: '', scanner3: '' });
  const [ewayBill, setEwayBill] = useState('');
  const [challaNo, setChallaNo] = useState('');
  const [expense, setExpense] = useState('');
  const [loadDate, setLoadDate] = useState('');
  const [showDatePicker, setShowDatePicker] = useState(false);

  const handleScan = (id, value) => {
    setQrValues((prev) => ({ ...prev, [id]: value }));
  };

  const onChangeDate = (event, selectedDate) => {
    const currentDate = selectedDate || loadDate;
    setShowDatePicker(false);
    setLoadDate(currentDate.toLocaleDateString());
  };

  const openDatePicker = () => {
    setShowDatePicker(true);
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.productName}>CIYA TECH TASK</Text>

        <Text style={styles.title}>QR Code Scanners</Text>

        {/* QRScanner with customized rectStyle for the scan box */}
        <QRScanner
          id="Product Scanner"
          onScan={(value) => handleScan('scanner1', value)}
          rectStyle={styles.rectStyle} // Applying custom gray scan box style
        />
        <QRScanner
          id="Code Scanner"
          onScan={(value) => handleScan('scanner2', value)}
          rectStyle={styles.rectStyle} // Applying custom gray scan box style
        />
        <QRScanner
          id="Barcode Scanner"
          onScan={(value) => handleScan('scanner3', value)}
          rectStyle={styles.rectStyle} // Applying custom gray scan box style
        />

        <TextInput
          placeholder="Eway-Bill No"
          value={ewayBill}
          onChangeText={setEwayBill}
          style={styles.input}
        />
        <TextInput
          placeholder="Challan No"
          value={challaNo}
          onChangeText={setChallaNo}
          style={styles.input}
        />
        <TextInput
          placeholder="Expense"
          value={expense}
          onChangeText={setExpense}
          keyboardType="numeric"
          style={styles.input}
        />

        {/* Load Date input */}
        <TouchableOpacity
          style={styles.input}
          onPress={openDatePicker}
        >
          <Text style={styles.inputText}>
            {loadDate ? loadDate : 'Select Load Date'}
          </Text>
        </TouchableOpacity>

        {/* DatePicker modal */}
        {showDatePicker && (
          <DateTimePicker
            value={new Date()}
            mode="date"
            display="default"
            onChange={onChangeDate}
          />
        )}

        <TouchableOpacity
          style={styles.button}
          onPress={() => onNext({ qrValues, ewayBill, challaNo, expense, loadDate })}
        >
          <Text style={styles.buttonText}>Next</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#D98586', // Dark peach background
  },
  scrollContainer: {
    paddingHorizontal: width * 0.05, // 5% padding on left and right
    paddingTop: height * 0.05, // 5% padding from top to raise the QR code scanner
    flexGrow: 1,
  },
  productName: {
    fontSize: width * 0.1, // 10% of screen width for the product name
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginBottom: height * 0.04, // 4% margin
  },
  title: {
    fontSize: width * 0.07, // 7% of screen width for title font size
    marginBottom: height * 0.03, // 3% margin below title
    color: '#fff',
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: width * 0.04, // 4% padding for input fields
    marginBottom: height * 0.02, // 2% margin between fields
    borderRadius: 8,
    backgroundColor: '#fff',
    justifyContent: 'center',
  },
  inputText: {
    fontSize: width * 0.04, // Smaller font size for placeholder
    color: '#333',
  },
  button: {
    backgroundColor: '#FF5733', // Button color
    paddingVertical: height * 0.02, // 2% vertical padding
    paddingHorizontal: width * 0.1, // 10% horizontal padding
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: height * 0.03, // 3% margin from the top (instead of too much space)
  },
  buttonText: {
    color: '#fff',
    fontSize: width * 0.05, // 5% of screen width for button text size
  },
  rectStyle: {
    borderColor: '#808080', // Gray border color for the scan box
    borderWidth: 2, // Set the border width to make it more visible
    borderRadius: 10, // Slightly rounded corners
  },
});
