import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Modal, FlatList, Alert } from 'react-native';
import * as Sharing from 'expo-sharing';  // Expo sharing API
import { PDFDocument, rgb } from 'react-native-pdf-lib';  // Library to create PDF

export default function Page2({ data, navigation }) {
  const [vehicleName, setVehicleName] = useState('');
  const [vehicleOwner, setVehicleOwner] = useState('');
  const [state, setState] = useState('');
  const [showVehicleNameModal, setShowVehicleNameModal] = useState(false);
  const [showOwnerModal, setShowOwnerModal] = useState(false);
  const [showStateModal, setShowStateModal] = useState(false);

  const vehicleNames = ['Truck', 'Van', 'Sedan', 'Bus', 'Motorcycle', 'SUV', 'Convertible', 'Hatchback'];
  const vehicleOwners = ['JAYESH SUKALE', 'GANESH SHENDGE', 'DHRUV KALE', 'SIYA ARORA', 'NEETA DEVI', 'AJAY DAS', 'ROHIT KUMAR', 'PRIYA SHARMA'];
  const states = ['Maharashtra', 'Gujrat', 'Delhi', 'Karnataka', 'Punjab', 'Rajasthan', 'Tamil Nadu', 'Uttar Pradesh'];

  const renderModalContent = (type) => {
    let data;
    if (type === 'vehicleName') {
      data = vehicleNames;
    } else if (type === 'vehicleOwner') {
      data = vehicleOwners;
    } else if (type === 'state') {
      data = states;
    }

    return (
      <FlatList
        data={data}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.modalItem}
            onPress={() => {
              if (type === 'vehicleName') {
                setVehicleName(item);
              } else if (type === 'vehicleOwner') {
                setVehicleOwner(item);
              } else if (type === 'state') {
                setState(item);
              }
              closeModal(type);
            }}
          >
            <Text style={styles.modalItemText}>{item}</Text>
          </TouchableOpacity>
        )}
      />
    );
  };

  const openModal = (type) => {
    if (type === 'vehicleName') setShowVehicleNameModal(true);
    else if (type === 'vehicleOwner') setShowOwnerModal(true);
    else if (type === 'state') setShowStateModal(true);
  };

  const closeModal = (type) => {
    if (type === 'vehicleName') setShowVehicleNameModal(false);
    else if (type === 'vehicleOwner') setShowOwnerModal(false);
    else if (type === 'state') setShowStateModal(false);
  };

  const handleSubmit = async () => {
    // Validate if all fields are selected
    if (!vehicleName || !vehicleOwner || !state) {
      Alert.alert('Error', 'Please fill all the details before submitting.');
      return;
    }
  
    try {
      // Generate the PDF document
      const pdfPath = await createPDF();
  
      // Show a success message after PDF is generated
      Alert.alert('Data Submitted', 'Your information has been submitted successfully!', [
        { text: 'OK', onPress: () => resetForm() },
      ]);
  
      // If sharing is available, share the PDF
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(pdfPath);
      } else {
        console.log('Sharing not available on this device.');
      }
    } catch (error) {
      console.log('Error generating or sharing the PDF:', error);
    }
  };
  

 


  const createPDF = async () => {
    try {
      // Create a new PDF document
      const pdfDoc = await PDFDocument.create();
  
      // Add a page to the document
      const page = pdfDoc.addPage();
  
      // Check if the page is properly created
      if (!page) {
        throw new Error('Failed to create a page in the PDF.');
      }
  
      // Define the content for the PDF
      const textContent = 'Hello, this is a test PDF!';
  
      // Draw text on the page at a specific position
      page.drawText(textContent, {
        x: 50,
        y: 750,
        fontSize: 12,
        color: rgb(0, 0, 0),
      });
  
      // Save the document and get the file path
      const pdfPath = await pdfDoc.write();
  
      console.log('PDF generated at:', pdfPath);
      return pdfPath;
    } catch (error) {
      console.error('Error generating PDF:', error);
    }
  };

  

  const resetForm = () => {
    setVehicleName('');
    setVehicleOwner('');
    setState('');
  };

  return (
    <View style={styles.container}>
      {/* Main Content */}
      <View style={styles.mainContent}>
        <Text style={styles.title}>QR Code Values</Text>
        <Text style={styles.qrText}>Scanner 1: {data.qrValues.scanner1}</Text>
        <Text style={styles.qrText}>Scanner 2: {data.qrValues.scanner2}</Text>
        <Text style={styles.qrText}>Scanner 3: {data.qrValues.scanner3}</Text>

        {/* Dropdowns stacked vertically */}
        <View style={styles.inputContainer}>
          {/* Vehicle Name Box */}
          <TouchableOpacity
            style={styles.inputBox}
            onPress={() => openModal('vehicleName')}
          >
            <Text style={styles.inputText}>{vehicleName || 'Select Vehicle Name'}</Text>
          </TouchableOpacity>

          {/* Vehicle Owner Box */}
          <TouchableOpacity
            style={styles.inputBox}
            onPress={() => openModal('vehicleOwner')}
          >
            <Text style={styles.inputText}>{vehicleOwner || 'Select Vehicle Owner'}</Text>
          </TouchableOpacity>

          {/* State Box */}
          <TouchableOpacity
            style={styles.inputBox}
            onPress={() => openModal('state')}
          >
            <Text style={styles.inputText}>{state || 'Select State'}</Text>
          </TouchableOpacity>
        </View>

        {/* Buttons side by side */}
        <View style={styles.buttonContainer}>
          {/* Back Button */}
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.buttonText}>Back</Text>
          </TouchableOpacity>

          {/* Submit Button */}
          <TouchableOpacity
            style={styles.submitButton}
            onPress={handleSubmit}
          >
            <Text style={styles.buttonText}>Submit</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Modals for Dropdowns */}
      {showVehicleNameModal && (
        <Modal
          transparent={true}
          visible={showVehicleNameModal}
          animationType="slide"
          onRequestClose={() => closeModal('vehicleName')}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              {renderModalContent('vehicleName')}
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => closeModal('vehicleName')}
              >
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}

      {showOwnerModal && (
        <Modal
          transparent={true}
          visible={showOwnerModal}
          animationType="slide"
          onRequestClose={() => closeModal('vehicleOwner')}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              {renderModalContent('vehicleOwner')}
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => closeModal('vehicleOwner')}
              >
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}

      {showStateModal && (
        <Modal
          transparent={true}
          visible={showStateModal}
          animationType="slide"
          onRequestClose={() => closeModal('state')}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              {renderModalContent('state')}
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => closeModal('state')}
              >
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
}




const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#D98586',
    padding: 10,
  },
  mainContent: {
    alignItems: 'center',
    marginTop: 20,
    paddingBottom: 20,
  },
  title: {
    fontSize: 24,
    color: '#fff',
    textAlign: 'center',
    marginVertical: 20,
  },
  qrText: {
    fontSize: 18,
    color: '#fff',
    marginVertical: 5,
  },
  inputContainer: {
    width: '100%',
    marginTop: 20,
  },
  inputBox: {
    padding: 15,
    backgroundColor: '#fff',
    marginVertical: 10,
    borderRadius: 5,
    width: '90%',  // Ensures all boxes are equal width
    alignItems: 'center',
    height: 50,  // All boxes will have the same height
  },
  inputText: {
    fontSize: 16,
    color: '#333',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
    marginTop: 20,
  },
  backButton: {
    padding: 15,
    backgroundColor: '#FF5733',
    borderRadius: 5,
    width: '48%',
  },
  submitButton: {
    padding: 15,
    backgroundColor: '#FF5733',
    borderRadius: 5,
    width: '48%',
  },
  buttonText: {
    fontSize: 18,
    color: '#fff',
    textAlign: 'center',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    width: 300,
  },
  modalItem: {
    padding: 10,
    borderBottomWidth: 1,
  },
  modalItemText: {
    fontSize: 16,
    color: '#333',
  },
  closeButton: {
    padding: 10,
    backgroundColor: '#FF5733',
    borderRadius: 5,
    marginTop: 10,
  },
  closeButtonText: {
    color: '#fff',
    fontSize: 16,
    textAlign: 'center',
  },
});
