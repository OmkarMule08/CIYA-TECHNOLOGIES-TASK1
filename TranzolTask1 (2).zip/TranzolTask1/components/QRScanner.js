import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function QRScanner({ id, onScan }) {
  const mockScan = () => {
    const mockValue = `Mock QR Value ${id}`;
    onScan(mockValue);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>QR Scanner {id}</Text>
      <Button title="Scan" onPress={mockScan} color="#00796b" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 5,
    shadowColor: '#a6ceb8 ',
    shadowOpacity: 0.6,
    shadowRadius: 5,
    elevation: 3,
  },
  title: {
    fontSize: 18,
    marginBottom: 10,
    color: '#581845',
  },
});
